<?php $__env->startSection('body'); ?>
    <div style="margin-top: 200px"></div>

    <div>
        <a href="<?php echo e(route('blogs.create')); ?>" class="btn btn-primary" > Create Article </a>
    </div>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">user</th>
            <th scope="col">title</th>
            <th scope="col">slug</th>
            <th scope="col">Category</th>
            <th scope="col">created At</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($article->id); ?></th>
            <td><?php echo e($article->user->name); ?></td>
            <td><?php echo e($article->title); ?></td>
            <td><?php echo e($article->slug); ?></td>
            <td>
            <?php $__currentLoopData = $article->categories()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/"><?php echo e($category->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td><?php echo e($article->created_at); ?></td>
            <td>
                <form action="/admin/blogs/<?php echo e($article->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>

                <a href="/admin/blogs/<?php echo e($article->id); ?>/edit" class="btn btn-success">Edit</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tohidda\Desktop\Udemy-laravel\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>