<?php $__env->startSection('title','New Site'); ?>
<?php $__env->startSection('body'); ?>




<?php if(auth()->guard()->guest()): ?>
    <?php if(empty($status)): ?>

    It is True

    <?php endif; ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tohidda\Desktop\Udemy-laravel\resources\views/udemy-laravel.blade.php ENDPATH**/ ?>