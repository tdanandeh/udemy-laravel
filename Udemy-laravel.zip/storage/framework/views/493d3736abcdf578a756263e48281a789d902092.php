<?php $__env->startSection('body'); ?>
<div style="margin-top: 200px"></div>
<div class="col-md-6" >
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>


        <?php endif; ?>
    <form action="<?php echo e(route('blogs.update', $article->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <h3> Blog Post</h3>
        <div class="form-group">
            <label for="exampleInputEmail1">Title</label>
            <input type="text" name="title" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
            value="<?php echo e($article->title); ?>">
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Slug</label>
            <input type="text" name="slug" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                   value="<?php echo e($article->slug); ?>">
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Category</label>
            <select name="category[]" id="" class="form-control" multiple>
                <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($category->id); ?>" <?php echo e(in_array($category->id, $article->categories()->pluck('id')->toArray()) ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Body</label>
            <textarea name="body" id="" cols="30" rows="10" class="form-control"><?php echo e($article->body); ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tohidda\Desktop\Udemy-laravel\resources\views/admin/blogs/edit.blade.php ENDPATH**/ ?>