<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\BlogRequest;
use App\Models\Article;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Redirector;

class BlogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Application|Factory|View
     */
    public function index()
    {

        $articles = Article::all();
        return view('admin.blogs.index',compact('articles'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Application|Factory|View
     */
    public function create()
    {
        return view('admin.blogs.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param BlogRequest $request
     * @return Application|RedirectResponse|Redirector
     */
    public function store(BlogRequest $request)
    {
//        Article::create([
//            'user_id' => auth()->user()->id,
//            'title' => $request->title,
//            'body' => $request->body,
//            'slug' => $request->slug,
//        ]);
     $blogs =   auth()->user()->articles()->create($request->all());

     $blogs->categories()->attach($request->input('category'));
        return redirect('/admin/blogs');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Application|Factory|View
     */
    public function edit($id)
    {
        $article = Article::find($id);
        return view('admin.blogs.edit',compact('article'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param BlogRequest $request
     * @param int $id
     * @return Application|RedirectResponse|Redirector
     */
    public function update(BlogRequest $request, $id)
    {

        $article = Article::findOrFail($id);
        $data = $request->except(['_token','_method','category']);
        auth()->user()->articles()->update($data);

        $article->categories()->sync($request['category']);
        return redirect('/admin/blogs');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        $article = Article::findOrFail($id);

        $article->delete();

        return back();
    }
}
