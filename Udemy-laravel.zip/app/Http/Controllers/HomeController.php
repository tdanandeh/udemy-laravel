<?php

namespace App\Http\Controllers;

use App\Mail\RegisterMail;
use App\Models\Article;
use App\Models\User;

use DebugBar\DebugBar;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class HomeController extends Controller
{

    public function __construct()
    {
       $this->middleware('auth')->except(['blog','about']);
    }

    public function index()
    {

//        $user = User::find(4);
//        return $user->articles()->get();
        $article = Article::find(4);
        return view('welcome');
    }

    public function blog()
    {
        $blogs = User::where('id', '>', '15')->get();
        return view('index', ['blogs' => $blogs]);
    }
    public function about()
    {
        return view('about');
    }
    public function contact()
    {
        return view('contact');
    }
    public function page()
    {
        return view('page');
    }
}
