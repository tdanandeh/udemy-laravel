@extends('layout.main')


@section('body')
<div style="margin-top: 200px"></div>
<div class="col-md-6" >
    @if($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach($errors->all() as $error)

                    <li>{{$error}}</li>
                @endforeach
            </ul>
        </div>


        @endif
    <form action="{{route('blogs.update', $article->id)}}" method="post">
        @csrf
        @method('PUT')
        <h3> Blog Post</h3>
        <div class="form-group">
            <label for="exampleInputEmail1">Title</label>
            <input type="text" name="title" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
            value="{{$article->title}}">
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Slug</label>
            <input type="text" name="slug" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                   value="{{$article->slug}}">
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Category</label>
            <select name="category[]" id="" class="form-control" multiple>
                @foreach(\App\Models\Category::all() as $category)

                    <option value="{{$category->id}}" {{in_array($category->id, $article->categories()->pluck('id')->toArray()) ? 'selected' : ''}}>{{$category->name}}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Body</label>
            <textarea name="body" id="" cols="30" rows="10" class="form-control">{{$article->body}}</textarea>
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

@endsection
