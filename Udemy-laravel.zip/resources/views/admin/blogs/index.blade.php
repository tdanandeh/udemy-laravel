@extends('layout.main')


@section('body')
    <div style="margin-top: 200px"></div>

    <div>
        <a href="{{route('blogs.create')}}" class="btn btn-primary" > Create Article </a>
    </div>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">user</th>
            <th scope="col">title</th>
            <th scope="col">slug</th>
            <th scope="col">Category</th>
            <th scope="col">created At</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        @foreach($articles as $article)
        <tr>
            <th scope="row">{{$article->id}}</th>
            <td>{{$article->user->name}}</td>
            <td>{{$article->title}}</td>
            <td>{{$article->slug}}</td>
            <td>
            @foreach($article->categories()->get() as $category)
                    <a href="/">{{$category->name}}</a>
                @endforeach
            </td>
            <td>{{$article->created_at}}</td>
            <td>
                <form action="/admin/blogs/{{$article->id}}" method="post">
                    @csrf
                    @method('delete')
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>

                <a href="/admin/blogs/{{$article->id}}/edit" class="btn btn-success">Edit</a>
            </td>
        </tr>
        @endforeach
        </tbody>
    </table>
@endsection
